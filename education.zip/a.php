<?php include("database.php"); 
ob_start();
$database = new Database();
?>
<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
<?php 
	

	$sql = $sql = "UPDATE teacher_appointment SET  province = '10', zone = '416' WHERE division = '417' OR division = '418' OR division = '419' OR division = '420' OR division = '421'";
		$table_update = $database -> query($sql);
?>
</body>
</html>