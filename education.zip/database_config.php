<?php

#page number 04

   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'education');

   ini_set("session.cookie_lifetime","172800");
?>