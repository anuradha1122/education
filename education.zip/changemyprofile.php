<?php include("database.php"); 
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SMS</title>
  <link rel="icon" type="image/png" href="img/title.gif">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }

    .features .glyphicon {

      font-size: 200px;
      padding-top: 10px;
      color: #cc6633;
    }

    .footer {

      background-color: black;
      color: white;

    }


    #list a:link { color: black; }
    #list a:visited { color: gray; }
    #list a:hover { color: #cc6633; }
    #list a:active { color: #cc6633; }


    #myNavbar a:link { color: white; }
    #myNavbar a:visited { color: white; }
    #myNavbar a:hover { color: #cc6633; }
    #myNavbar a:active { color: green; }

    #brand-text a:link { color: white; }
    #brand-text a:visited { color: white; }
    #brand-text a:hover { color: #cc6633; }
    #brand-text a:active { color: green; }
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }



    /* Hide the carousel text when the screen is less than 600 pixels wide */
    @media (max-width: 600px) {
      .carousel-caption {
        display: none; 
      }
    }


    input[type=text], select, [type=date], [type=password] {
    width: 100%;
    padding: 4px 10px;
    margin: 1px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-sizing: border-box;
    }


    input[type=submit] {
        width: 32%;
        background-color: black;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 10px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color: #cc6633;
    }

    td {

      height: 10px;
    }

    #tableField {
      width: 40%;
      text-align: right;
      
    }

    #tableBox {
      width: 60%;
      text-align:left;

    }

    #tableErr {
      width: 30%;
      text-align:left;
      color: red;

    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header" id="brand-text">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home.php">Education</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php?id=logout"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<?php

#page number 11

$database = new Database();

$database -> empty_session();
$database ->restricted_page('11');
$activity = "";
$email_err = $emp_err = $cpw_err = $success = $pw_err = "";
$position     = $database -> find_position();
if($_SERVER["REQUEST_METHOD"] == "POST"){

	if(isset($_POST['submit'])){

    
    $id           = $database -> find_id();
    
    if(isset($_POST['add_li1']) AND $_POST['add_li1'] <> ''){

        $add_li1      = $database -> post_to_variabal($_POST['add_li1']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'add_li1', $add_li1, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'add_li1', $add_li1, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'add_li1', $add_li1, 'tc_id', $id);
        }

        $activity .= ".6";
    }

    if(isset($_POST['add_li2']) AND $_POST['add_li2'] <> ''){

        $add_li2      = $database -> post_to_variabal($_POST['add_li2']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'add_li2', $add_li2, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'add_li2', $add_li2, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'add_li2', $add_li2, 'tc_id', $id);
        }

        $activity .= ".7";
    }

    if(isset($_POST['add_li3']) AND $_POST['add_li3'] <> ''){

        $add_li3      = $database -> post_to_variabal($_POST['add_li3']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'add_li3', $add_li3, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'add_li3', $add_li3, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'add_li3', $add_li3, 'tc_id', $id);
        }

        $activity .= ".8";
    }
    
    if(isset($_POST['division']) AND $_POST['division'] <> ''){

        $division     = $database -> post_to_variabal($_POST['division']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'division', $division, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'division', $division, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'division', $division, 'tc_id', $id);
        }   
        $activity .= ".9";
    }

    if(isset($_POST['tel']) AND $_POST['tel'] <> ''){

        $tel          = $database -> post_to_variabal($_POST['tel']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'tel_no', $tel, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'tel_no', $tel, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'tel_no', $tel, 'tc_id', $id);
        }
        
        
        $activity .= ".9";
    }

    if(isset($_POST['sec_sub']) AND $_POST['sec_sub'] <> ''){

        $sec_sub      = $database -> post_to_variabal($_POST['sec_sub']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'sec_sub', $sec_sub, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'sec_sub', $sec_sub, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'sec_sub', $sec_sub, 'tc_id', $id);
        }   
        
        $activity .= ".10";
    }

    if(isset($_POST['third_sub']) AND $_POST['third_sub'] <> ''){

        $third_sub      = $database -> post_to_variabal($_POST['third_sub']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'third_sub', $third_sub, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'third_sub', $third_sub, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'third_sub', $third_sub, 'tc_id', $id);
        }   
        
        $activity .= ".11";
    }

    if(isset($_POST['forth_sub']) AND $_POST['forth_sub'] <> ''){

        $forth_sub      = $database -> post_to_variabal($_POST['forth_sub']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'forth_sub', $forth_sub, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'forth_sub', $forth_sub, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'forth_sub', $forth_sub, 'tc_id', $id);
        }   
        
        $activity .= ".12";
    }

    if(isset($_POST['fifth_sub']) AND $_POST['fifth_sub'] <> ''){

        $fifth_sub      = $database -> post_to_variabal($_POST['fifth_sub']);
        if($position =='ad_id'){
            $update       = $database -> update_one_column('admin_staff', 'fifth_sub', $fifth_sub, 'ad_id', $id);
        }elseif($position =='pr_id'){
            $update       = $database -> update_one_column('principal', 'fifth_sub', $fifth_sub, 'pr_id', $id);
        }elseif($position =='tc_id'){
            $update       = $database -> update_one_column('teacher', 'fifth_sub', $fifth_sub, 'tc_id', $id);
        }   
        
        $activity .= ".10";
    }

    if(isset($_POST['email']) AND $_POST['email'] <> ''){
        $email        = $database -> form_data_process('email');
        $email        = $database -> email_validation($email);
        
        if($email <> ''){
            if($position =='ad_id'){
                $email        = $database -> email_existance($email,'admin_staff','email');
                $email_err    = $database -> field_missing($email,'Invalied email format or email already exist');
                $update       = $database -> update_one_column('admin_staff', 'email', $email, 'ad_id', $id);
            }elseif($position =='pr_id'){
                $email        = $database -> email_existance($email,'principal','email');
                $email_err    = $database -> field_missing($email,'Invalied email format or email already exist');
                $update       = $database -> update_one_column('principal', 'email', $email, 'pr_id', $id);
            }elseif($position =='tc_id'){
                $email        = $database -> email_existance($email,'teacher','email');
                $email_err    = $database -> field_missing($email,'Invalied email format or email already exist');
                $update       = $database -> update_one_column('teacher', 'email', $email, 'tc_id', $id);
            }
            $activity .= ".11";
        }      
    }

    if(isset($_POST['password']) AND $_POST['password'] <> '' AND isset($_POST['cpassword']) AND $_POST['cpassword'] <> ''){
        $password     = $database -> form_data_process('password');
        $password     = crypt($password,'$2a$09$anexamplestringforsalt$');

        $cpassword    = $database -> form_data_process('cpassword');
        $cpassword    = crypt($cpassword,'$2a$09$anexamplestringforsalt$');

        if($password == $cpassword){
            if($position =='ad_id'){
                $update       = $database -> update_one_column('admin_staff', 'password', $password, 'ad_id', $id);
            }elseif($position =='pr_id'){
                $update       = $database -> update_one_column('principal', 'password', $password, 'pr_id', $id);
            }elseif($position =='tc_id'){
                $update       = $database -> update_one_column('teacher', 'password', $password, 'tc_id', $id);
            }
            $activity .= ".12";
        } else{

            $pw_err   = $database -> text_to_variabal('password did not Match');
        }
    }

	}
  if(isset($_POST['cancel'])){

    $database -> headerto('changeteacherprofile.php');

  }
  if(isset($_POST['back'])){

    $database -> headerto('home.php');
  }
}
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 text-center">
      <h3>CHANGE YOUR PROFILE</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-4 col-sm-offset-4 col-xs-offset-0 justify-content-center">
      <form method="post" action="">
      <table class = "table table-hover">

    <tr>
    <td id="tableField">
    Address Line 1:
    </td>
    <td id="tableBox">
    <input type="text" name="add_li1" value="">
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Address Line 2:
    </td>
    <td id="tableBox">
    <input type="text" name="add_li2" value="">
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Address Line 3:
    </td>
    <td id="tableBox">
    <input type="text" name="add_li3" value="">
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Residential Edu: Division:
    </td>
    <td id="tableBox">
    <select name="division"><option value="" selected>No Change</option><?php $div_query = $database -> find_division();
      while($division = mysqli_fetch_assoc($div_query)){ ?> 
      <option value="<?php echo $division['eo_id']; ?>"><?php echo $division['name']?></option> <?php }?> </select>
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Telephone:
    </td>
    <td id="tableBox">
    <input type="text" name="tel" value="">
    </td>
    </tr>
    <?php if($position == 'tc_id') { ?>
    <tr>
    <td id="tableField">
    Teaching Subject 1:
    </td>
    <td id="tableBox">
    <select name="sec_sub"><option value="" selected>No Change</option> <?php $sub_query = $database ->table_search('subject');
      while($subject = mysqli_fetch_assoc($sub_query)){ ?> 
      <option value="<?php echo $subject['su_id']; ?>"><?php echo $subject['name']?></option> <?php } ?></select>
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Teaching Subject 2:
    </td>
    <td id="tableBox">
    <select name="third_sub"><option value="" selected>No Change</option><?php $sub_query = $database ->table_search('subject');
      while($subject = mysqli_fetch_assoc($sub_query)){?> 
      <option value="<?php echo $subject['su_id']; ?>"><?php echo $subject['name']?></option> <?php } ?></select>
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Teaching Subject 3:
    </td>
    <td id="tableBox">
    <select name="forth_sub"><option value="" selected>No Change</option><?php $sub_query = $database ->table_search('subject');
      while($subject = mysqli_fetch_assoc($sub_query)){?> 
      <option value="<?php echo $subject['su_id']; ?>"><?php echo $subject['name']?></option> <?php } ?></select>
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Teaching Subject 4:
    </td>
    <td id="tableBox">
    <select name="fifth_sub"><option value="" selected>No Change</option><?php $sub_query = $database ->table_search('subject');
      while($subject = mysqli_fetch_assoc($sub_query)){?> 
      <option value="<?php echo $subject['su_id']; ?>"><?php echo $subject['name']?></option> <?php } ?></select>
    </td>
    </tr>
    <?php } ?>
    
    <tr>
    <td id="tableField">
    E-mail:
    </td>
    <td id="tableBox">
    <input type="text" name="email" value="">
    </td>
    </tr>

    <?php if($email_err !=""){ ?>
    <tr>
    <td id="tableField">
    </td>
    <td id="tableBox" class="text-danger">
    <?php $database -> display_message($email_err); ?>
    </td>
    </tr>
    <?php } ?>

    <tr>
    <td id="tableField">
    Pass Word:
    </td>
    <td id="tableBox">
    <input type="password" name="password" maxlength="10" minlength="6" value="">
    </td>
    </tr>

    <tr>
    <td id="tableField">
    Confirm Pass Word:
    </td>
    <td id="tableBox">
    <input type="password" name="cpassword" maxlength="10" minlength="6" value="">
    </td>
    </tr>

    <?php if($pw_err !=""){ ?>
    <tr>
    <td id="tableField">
    </td>
    <td id="tableBox" class="text-danger">
    <?php $database -> display_message($pw_err); ?>
    </td>
    </tr>
    <?php } ?>

   </table>
    </div>
  </div>
    <div class="row">
      <div class="col-sm-6 col-sm-offset-3 col-xs-offset-0 justify-content-center">
        
        <input id="button" type="submit" name="submit" value="Submit">
        <input id="button" type="submit" name="cancel" value="Refresh">
        <input id="button" type="submit" name="back" value="Back">
          </form>
      </div>  
     </div>
       
    <?php $database -> conditional_display($success); ?> 
    </form>
    
</div>
<footer class="container-fluid text-center">
  <div class="row footer">
    <p>2018 Copyright: xcodeweb.com</p>
  </div>
</footer>

