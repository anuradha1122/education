<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'cremapps_education');
   define('DB_PASSWORD', 'cremapps_education');
   define('DB_DATABASE', 'cremapps_education');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>